package com.roms.packagingdelivery.exception;

public class ComponentTypeNotFoundException extends RuntimeException {
    public ComponentTypeNotFoundException(String msg)
    {
        super(msg);
    }
}
